/*
** Lua binding: tolua
** Generated automatically by tolua++-1.0.8pre2 on Tue Dec 13 01:43:55 2005.
*/

/* Exported function */
TOLUA_API int  tolua_tolua_open (lua_State* tolua_S);

